module.exports = {
    STORE_DBURL: process.env.STORE_DBURL,
    STORE_DBNAME: process.env.STORE_DBNAME,
    STORE_COLLECTIONNAME: process.env.STORE_COLLECTIONNAME,
}