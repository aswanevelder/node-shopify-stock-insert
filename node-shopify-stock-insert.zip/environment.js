module.exports = {
    STORE_DBURL: process.env.SHOPIFY_DBURL,
    STORE_DBNAME: process.env.SHOPIFY_DBNAME,
    STORE_COLLECTIONNAME: process.env.STORE_COLLECTIONNAME,
}